"""
【题目描述】
	给出两个字符串s_1,s_2（(只有大写字母），求s_1在s_2中出现多少次。
	例如：s_1=\"ABA\",s_2=\"ABAABA\",答案为2。
【输入】
	输入T组数据，每组数据输出结果。
【输出】
	如题述。
【输入样例】
	3
	BAPC
	BAPC
	AZA
	AZAAZAAZA
	VEEDI
	AVERDXIVYERDLAN
【输出样例】
	1
	3
	0

"""