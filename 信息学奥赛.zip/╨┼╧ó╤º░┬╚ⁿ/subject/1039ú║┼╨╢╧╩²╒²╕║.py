"""
【题目描述】
	给定一个整数N，判断其正负。如果N>0，输出positive；如果N=0，输出zero；如果N&lt;0，输出negative。
【输入】
	一个整数N(-10^9 ≤ N ≤ 10^9)。
【输出】
	如果N > 0, 输出<code>positive</code>;
	如果N = 0, 输出<code>zero</code>;
	如果N &lt; 0, 输出<code>negative</code>。
【输入样例】
	1
【输出样例】
	positive
 
"""