"""
				特别说明：
						 --> \\frac <-- 表示分数,
						 \\frac{a}{b} === a/b,
						 \\frac{a}{\\frac{b} + \\frac{c}} === a/(b+c)
【题目描述】
	编写程序，计算下列分段函数y=f(x)的值。结果保留到小数点后三位。
	 &nbsp; &nbsp; y=-x+2.5; \\quad \\quad 0≤x&lt;5
	 &nbsp; &nbsp; y=2-1.5(x-3)(x-3); \\quad\\quad 5≤x&lt;10
	 &nbsp; &nbsp; y=\\frac{x}{2}-1.5; \\quad\\quad 10≤x&lt;20
【输入】
	一个浮点数N(0 ≤ N &lt; 20)。
【输出】
	输出 N 对应的分段函数值：f(N)。结果保留到小数点后三位。
【输入样例】
	1.0
【输出样例】
	1.500
 
"""