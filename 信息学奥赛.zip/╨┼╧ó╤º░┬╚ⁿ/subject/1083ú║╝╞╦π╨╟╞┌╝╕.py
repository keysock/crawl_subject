"""
【题目描述】
	假设今天是星期日，那么过a^b天之后是星期几？
【输入】
	两个正整数a，b，中间用单个空格隔开。0&lt;a≤100, 0&lt;b≤10000。
【输出】
	一个字符串，代表过a^b天之后是星期几。
	其中，<code>Monday</code>是星期一，<code>Tuesday</code>是星期二，<code>Wednesday</code>是星期三，<code>Thursday</code>是星期四，<code>Friday</code>是星期五，<code>Saturday</code>是星期六，<code>Sunday</code>是星期日。
【输入样例】
	3 2000
【输出样例】
	Tuesday
 
"""