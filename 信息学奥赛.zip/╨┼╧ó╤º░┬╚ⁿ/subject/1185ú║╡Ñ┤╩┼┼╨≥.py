"""
【题目描述】
	输入一行单词序列，相邻单词之间由1个或多个空格间隔，请按照字典序输出这些单词，要求重复的单词只输出一次。（区分大小写）
【输入】
	一行单词序列，最少1个单词，最多100个单词，每个单词长度不超过50，单词之间用至少1个空格间隔。数据不含除字母、空格外的其他字符。
【输出】
	按字典序输出这些单词，重复的单词只输出一次。
【输入样例】
	She  wants  to go to Peking University to study  Chinese
【输出样例】
	Chinese
	Peking
	She
	University
	go
	study
	to
	wants
	
 
"""