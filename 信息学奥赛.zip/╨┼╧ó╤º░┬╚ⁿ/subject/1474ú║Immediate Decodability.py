"""
【题目描述】
	原题来自：ACM Pacific NW Region 1998
	给出一些数字串，判断是否有一个数字串是另一个串的前缀。
【输入】
	输入数据为多组数据，每组数据读到 9 时结束。
【输出】
	对于每组数据，如果不存在一个数字串是另一个串的前缀，输出一行 Set t is immediately decodable ，否则输出一行 Set t is not immediately decodable ，其中 t 是这一组数据的组号。
【输入样例】
	01
	10
	0010
	0000
	9
	01
	10
	010
	0000
	9
【输出样例】
	Set 1 is immediately decodable
	Set 2 is not immediately decodable

"""