"""
【题目描述】
	6&times;9=42对于十进制来说是错误的，但是对于13进制来说是正确的。即, 6<sub>(13)</sub>&times; 9<sub>(13)</sub>= 42<sub>(13)</sub>， 而 42<sub>(13)</sub>=4&times;13<sup>1</sup>+2&times;13<sup>0</sup>=54<sub>(10)</sub>。
	你的任务是写一段程序，读入三个整数p、q和 r，然后确定一个进制 B(2&lt;=B&lt;=40) 使得 p &times; q = r。 如果 B 有很多选择, 输出最小的一个。
	例如：p=11, q=11, r=121.则有11<sub>(3)</sub>&times; 11<sub>(3)</sub>= 121<sub>(3)</sub>因为 11<sub>(3)</sub>= 1 &times; 3<sup>1</sup>+ 1 &times; 3<sup>0</sup>= 4<sub>(10)</sub>和121<sub>(3)</sub>=1&times;3<sup>2</sup>+2&times;3<sup>1</sup>+1&times;3<sup>0</sup>=16<sub>(10)</sub>。对于进制 10，同样有11<sub>(10)</sub>&times; 11<sub>(10)</sub>= 121<sub>(10)</sub>。这种情况下，应该输出 3。如果没有合适的进制，则输出 0。
【输入】
	一行，包含三个整数p、q、r。 p、q、r的所有位都是数字，并且1 &le; p、q、r ≤ 1,000,000。
【输出】
	一个整数：即使得p×q=r成立的最小的B。如果没有合适的B，则输出0。
【输入样例】
	6 9 42
【输出样例】
	13
 
"""